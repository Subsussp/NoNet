import Products from "pages/control/Products"

const Order = () => {
    return (
        <>
        <div>
         
        </>
    )
}

export default Order