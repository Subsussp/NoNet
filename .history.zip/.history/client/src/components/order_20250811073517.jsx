import Products from "pages/control/Products"
import { useEffect, useState } from "react"
import { API_BASEURL } from "Var/URLS"
import LocationPicker from "./Mapicker"



const Order = () => {
  const [orders,setorders] = useState([])
  const [showLocation, setShowLocation] = useState(null);

  const toggleMap = (orderId) => {
    setVisibleMapOrderId((prev) => (prev === orderId ? null : orderId));
  };

  useEffect(()=>{
     const getorders = async () => {
      let data = await (await fetch(`${API_BASEURL}/order`,{method:'GET',credentials:'include'})).json()
      setorders(data.data)
}
   getorders()

  },[])
  if(orders.length < 1){
    return (
        <div>Loading...</div>)
  }
return (
    <div className="w-screen h-screen flex flex-col p-6 bg-gradient-to-br from-gray-50 to-gray-200">
      <h1
        className="text-4xl font-bold mb-8 text-gray-800"
        style={{ fontFamily: 'Cinzel' }}
      >
        Orders
      </h1>

      <div className="flex-1 overflow-y-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {orders.map((order) => (
            <div
              key={order._id}
              className="bg-white shadow-lg rounded-2xl p-6 flex flex-col justify-between"
              style={{ fontFamily: 'Poppins' }}
            >
              <div>
                <h2 className="text-xl font-semibold text-gray-900">
                  Order #{order._id.slice(-6)}
                </h2>
                <p className="text-sm text-gray-500 mt-1">
                  Placed on {new Date(order.createdAt).toLocaleDateString()}
                </p>

                <div className="mt-4">
                  <h3 className="font-semibold text-gray-700">Items</h3>
                  <ul className="text-gray-600 text-sm list-disc ml-5">
                    {order.items.map((item, i) => (
                      <li key={i}>
                        {item.name} × {item.quantity} — ${item.price}
                      </li>
                    ))}
                  </ul>
                </div>

                <p className="mt-4 text-gray-800 font-medium">
                  Total: ${order.total}
                </p>
              </div>

              <button
                onClick={() => setShowLocation(order.address.coordinates)}
                className="mt-6 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl font-medium transition-all"
              >
                Show Location
              </button>
            </div>
          ))}
        </div>
      </div>

      {showLocation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white rounded-xl p-4 shadow-xl max-w-lg w-full">
            <LocationPicker coordinates={showLocation} />
            <button
              onClick={() => setShowLocation(null)}
              className="mt-4 px-4 py-2 bg-red-500 text-white rounded-xl hover:bg-red-600"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
export default Order