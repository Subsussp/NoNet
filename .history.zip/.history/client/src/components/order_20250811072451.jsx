import Products from "pages/control/Products"
import { useEffect, useState } from "react"
import { API_BASEURL } from "Var/URLS"

 const getorders = async () => {
  let data = await fetch(`${API_BASEURL}/order`,{method:'GET',credentials:'include'})
  return data
}

const Order = () => {
  let [orders,setorders] = useState([])
  useEffect(a ()=>{
    await getorders()
  },[])
    return (
        <>
        <div>
        
</div>
        </>
    )
}

export default Order