import Products from "pages/control/Products"

const Order = () => {
    return (
        <>
        <div>
        
         </div>
        </>
    )
}

export default Order