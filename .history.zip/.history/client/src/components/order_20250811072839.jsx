import Products from "pages/control/Products"
import { useEffect, useState } from "react"
import { API_BASEURL } from "Var/URLS"
import LocationPicker from "./Mapicker"

 const getorders = async () => {
  let data = await fetch(`${API_BASEURL}/order`,{method:'GET',credentials:'include'})
  return data
}

const Order = () => {
  const [orders,setorders] = useState([])
  const [visibleMapOrderId, setVisibleMapOrderId] = useState(null);

  const toggleMap = (orderId) => {
    setVisibleMapOrderId((prev) => (prev === orderId ? null : orderId));
  };

  useEffect(async ()=>{
    let data = await getorders()
    setorders(data)
  },[])
  if(orders.length < 1){
    return (
        <div>Loading...</div>)
  }
  console.log(orders)
  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8">
      <h1 className="text-3xl font-bold mb-6 text-gray-800">My Orders</h1>

      {orders.length === 0 ? (
        <p className="text-center text-gray-500 italic">You have no orders yet.</p>
      ) : (
        <div className="space-y-6">
          {orders.map((order) => (
            <div
              key={order._id}
              className="border rounded-lg shadow-sm p-6 bg-white"
            >
              {/* Order Summary */}
              <div className="flex flex-col md:flex-row md:justify-between md:items-center space-y-4 md:space-y-0">
                <div>
                  <h2 className="text-xl font-semibold text-gray-900">
                    Order #{order._id.slice(-6).toUpperCase()}
                  </h2>
                  <p className="text-gray-700">
                    <span className="font-medium">Status:</span> {order.orderStatus}
                  </p>
                  <p className="text-gray-700">
                    <span className="font-medium">Total:</span> ${order.totalAmount.toFixed(2)}
                  </p>
                </div>

                <div className="text-right">
                  <button
                    onClick={() => toggleMap(order._id)}
                    className="inline-block rounded bg-blue-600 text-white px-4 py-2 hover:bg-blue-700 transition"
                  >
                    {visibleMapOrderId === order._id ? "Hide Coordinates" : "Show Coordinates"}
                  </button>
                </div>
              </div>

              {/* Shipping Address */}
              <div className="mt-4 text-gray-700">
                <p><span className="font-medium">Shipping to:</span> {order.shippingAddress.fullName}</p>
                <p>{order.shippingAddress.address}</p>
                <p>{order.shippingAddress.city}, {order.shippingAddress.country} {order.shippingAddress.zipCode}</p>
                <p>Phone: {order.shippingAddress.phone}</p>
              </div>

              {/* Location Picker Map - toggled */}
              {visibleMapOrderId === order._id && order.shippingAddress?.coords && (
                <div className="mt-4 h-64 rounded overflow-hidden shadow-md">
                  <LocationPicker
                    coords={order.shippingAddress.coords} 
                    onLocationSelected={() => {}} 
                    setZipcode={() => {}}
                  />
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
export default Order