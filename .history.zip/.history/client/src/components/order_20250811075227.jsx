import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { FiPhone, FiMapPin, FiMail } from "react-icons/fi";
import { API_BASEURL } from "Var/URLS"
import LocationPicker from "./Mapicker"

function updateOrderStatus(){
  return ''
}

const Order = () => {
  const [orders,setOrders] = useState([])
  const [filter, setFilter] = useState("pending");
  const [search, setSearch] = useState("");
  const [locationModal, setLocationModal] = useState({ open: false, coords: null });
  
  const filteredOrders = orders.filter(order => {
    const matchesStatus = filter === "all" || order.orderStatus === filter;
    const matchesSearch =
      order.customerName?.toLowerCase().includes(search.toLowerCase()) ||
      order.email?.toLowerCase().includes(search.toLowerCase()) ||
      order._id?.toLowerCase().includes(search.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleStatusToggle = async (orderId, currentStatus) => {
    const newStatus = currentStatus === "delivered" ? "pending" : "delivered";
    await updateOrderStatus(orderId, newStatus);
    setOrders(prev =>
      prev.map(o => (o._id === orderId ? { ...o, status: newStatus } : o))
    );
  };
  useEffect(()=>{
     const getorders = async () => {
      let data = await (await fetch(`${API_BASEURL}/order`,{method:'GET',credentials:'include'})).json()
      setOrders(data.data)
}
   getorders()

  },[])
  if(orders.length < 1){
    return (
        <div>Loading...</div>)
  }
  console.log(orders)

  return (
    <div className="w-full h-screen bg-gray-50 p-6 flex flex-col font-Poppins">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-3xl font-bold text-gray-800 font-Cinzel">Orders</h1>
        <div className="flex space-x-2">
          {["pending", "delivered", "all"].map(tab => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-4 py-2 rounded-lg font-medium capitalize ${
                filter === tab
                  ? "bg-blue-600 text-white"
                  : "bg-gray-200 text-gray-800"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Search */}
      <div className="flex items-center bg-white rounded-lg px-3 py-2 mb-4 shadow-sm">
        <FaSearch className="text-gray-400" />
        <input
          type="text"
          placeholder="Search by name, email, or ID..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="ml-2 w-full outline-none bg-transparent"
        />
      </div>

      {/* Orders list */}
      <div className="overflow-y-auto flex-1 space-y-4">
        {filteredOrders.length === 0 && (
          <p className="text-gray-500 text-center mt-10">No orders found.</p>
        )}

        {filteredOrders.map(order => (
          <motion.div
            key={order._id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white shadow-md rounded-lg p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center"
          >
            <div className="flex flex-col space-y-1">
              <h2 className="font-semibold text-lg">{order.customerName}</h2>
              <p className="text-gray-600 text-sm">{order.email}</p>
              <p className="text-gray-600 text-sm"><FiMapPin className="mr-2 text-red-500" />
 {order.phone}</p>
              <p className="text-gray-600 text-sm">📍 {order.address}</p>
              <p className="text-sm font-medium">
                Status:{" "}
                <span
                  className={`${
                    order.orderStatus === "delivered"
                      ? "text-green-600"
                      : "text-yellow-600"
                  }`}
                >
                  {order.orderStatus}
                </span>
              </p>
            </div>

            <div className="flex space-x-2 mt-3 sm:mt-0">
              <button
                onClick={() =>
                  setLocationModal({ open: true, coords: order.coords })
                }
                className="px-3 py-2 bg-blue-500 text-white rounded-lg flex items-center space-x-1 hover:bg-blue-600"
              >
                <FaMapMarkerAlt />
                <span>Location</span>
              </button>
              <button
                onClick={() => handleStatusToggle(order._id, order.orderStatus)}
                className={`px-3 py-2 rounded-lg flex items-center space-x-1 ${
                  order.orderStatus === "delivered"
                    ? "bg-yellow-500 hover:bg-yellow-600 text-white"
                    : "bg-green-500 hover:bg-green-600 text-white"
                }`}
              >
                {order.orderStatus === "delivered" ? <FaTimes /> : <FaCheck />}
                <span>
                  {order.orderStatus === "delivered" ? "Mark Pending" : "Mark Delivered"}
                </span>
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Location Modal */}
      {locationModal.open && (
        <LocationPicker
          coords={locationModal.coords}
          onLocationSelected={() => setLocationModal({ open: false, coords: null })}
        />
      )}
    </div>
  );
}
export default Order