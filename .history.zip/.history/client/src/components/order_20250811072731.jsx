import Products from "pages/control/Products"
import { useEffect, useState } from "react"
import { API_BASEURL } from "Var/URLS"

 const getorders = async () => {
  let data = await fetch(`${API_BASEURL}/order`,{method:'GET',credentials:'include'})
  return data
}

const Order = () => {
  let [orders,setorders] = useState([])
    const [visibleMapOrderId, setVisibleMapOrderId] = useState(null);

  // Toggle map visibility for a given order id
  const toggleMap = (orderId) => {
    setVisibleMapOrderId((prev) => (prev === orderId ? null : orderId));
  };
  useEffect(async ()=>{
    let data = await getorders()
    setorders(data)
  },[])
  if(!orders){
    return (
        <div>Loading...</div>)
  }
  return (
    <><div></div></>
    )
}

export default Order