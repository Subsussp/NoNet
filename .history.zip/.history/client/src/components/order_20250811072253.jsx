import Products from "pages/control/Products"
fetch
const Order = () => {

    return (
        <>
        <div>
        
</div>
        </>
    )
}

export default Order