import Products from "pages/control/Products"

const Order = () => {
    return (
        <>
        <div>
          Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia itaque molestias minus ipsam ratione cumque qui similique laborum. Voluptas magni impedit aspernatur nulla inventore, voluptatum sint illum cum ratione placeat.  
          Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia itaque molestias minus ipsam ratione cumque qui similique laborum. Voluptas magni impedit aspernatur nulla inventore, voluptatum sint illum cum ratione placeat.  
          Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia itaque molestias minus ipsam ratione cumque qui similique laborum. Voluptas magni impedit aspernatur nulla inventore, voluptatum sint illum cum ratione placeat.  
          Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia itaque molestias minus ipsam ratione cumque qui similique laborum. Voluptas magni impedit aspernatur nulla inventore, voluptatum sint illum cum ratione placeat.  
        </div>
        </>
    )
}

export default Order