import Products from "pages/control/Products"
import { useEffect } from "react"

const Order = () => {
  useEffect(()=>{
    
  },[])
    return (
        <>
        <div>
        
</div>
        </>
    )
}

export default Order