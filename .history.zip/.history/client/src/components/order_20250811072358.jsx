import Products from "pages/control/Products"
import { useEffect, useState } from "react"

 const getorders = () => {
  fetch(`${}`)
  return 
}

const Order = () => {
  let [orders,setorders] = useState([])
  useEffect(()=>{
    
  },[])
    return (
        <>
        <div>
        
</div>
        </>
    )
}

export default Order